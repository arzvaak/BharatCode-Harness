import type { FetchFn } from './common.js';
import { NpmCliVersionCache } from './npm-cli-version.js';
/**
 * Public metadata only: never send subscription credentials to this endpoint.
 * `latest`, not `stable`: the endpoint gates new models on versions that
 * reach `stable` about a week later.
 */
export declare const CLAUDE_CLI_VERSION_URL = "https://registry.npmjs.org/@anthropic-ai%2fclaude-code/latest";
/**
 * Lazy, shared-per-plugin lookup of Claude Code's newest release, never
 * below the local CLI or the bundled fallback version.
 */
export declare class ClaudeCliVersionCache extends NpmCliVersionCache {
    constructor(fetchFn?: FetchFn, now?: () => number, timeoutMs?: number, detect?: () => string);
}
